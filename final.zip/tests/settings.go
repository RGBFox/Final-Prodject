package tests

var Port = 7540
var DBFile = "../scheduler.db"
var FullNextDate = false
var Search = false
var Token = `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3OTQzNTQ4NjAsImlhdCI6MTc5NDMyNjA2MH0.dDEt5eCZAY2rYQrd3vwLBLkR6GV5GAIHMGuNgbbdhR8`
